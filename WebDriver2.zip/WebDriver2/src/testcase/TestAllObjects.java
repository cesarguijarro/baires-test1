package testcase;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import helper.StartWebDriver;

public class TestAllObjects extends StartWebDriver{

	@Test
	public void testAll() {
		List<WebElement> link = driver.findElements(By.tagName("a"));
		// all the hyperlink have the tagname "a"
		for (WebElement ele : link) {
			System.out.println("Link :" +ele.getText());
			System.out.println("Href :" + ele.getAttribute("href"));
			System.out.println("----------------------");
		}
		System.out.println("************+ ***************  ***********");		
		List<WebElement> cla = driver.findElements(By.cssSelector(".txt"));
		

		for (WebElement ele : cla) {
			System.out.println("id :" +ele.getAttribute("id"));
			System.out.println("name: 	" + ele.getAttribute("name"));
			System.out.println("title: 	" + ele.getAttribute("title"));
			System.out.println("----------------------");
		}
	}
	
}
