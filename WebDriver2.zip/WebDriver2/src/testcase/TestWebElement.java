package testcase;

import helper.ButtonHelper;
import helper.CheckBoxHelper;
import helper.LinkHelper;
import helper.StartWebDriver;
import helper.TextBoxHelper;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.testng.annotations.Test;

public class TestWebElement extends StartWebDriver {
	
	@Test
	public void findElemet() {
		try {
				LinkHelper.clickLink("File a Bug");
				/*System.out.println("Selected : " + driver.findElement(By.id("Bugzilla_restrictlogin")).isSelected());
				driver.findElement(By.id("Bugzilla_restrictlogin")).click();
				System.out.println("Selected : " + driver.findElement(By.id("Bugzilla_restrictlogin")).isSelected());*/
				
				System.out.println("Selected : " + CheckBoxHelper.isChecked("Bugzilla_restrictlogin"));
				CheckBoxHelper.clickCheckBox("Bugzilla_restrictlogin");
				System.out.println("Selected : " + CheckBoxHelper.isChecked("Bugzilla_restrictlogin"));
				
				//driver.findElement(By.id("log_in")).click();
				ButtonHelper.clickButton("log_in");
		} catch (NoSuchElementException e) {
			e.printStackTrace();
		}
		
	}

}