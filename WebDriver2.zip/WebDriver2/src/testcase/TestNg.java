package testcase;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

public class TestNg {

	private static  WebDriver driver = null;
	
	@BeforeClass
	public static void startWebDriver() {
		// FireFox Profile 
		ProfilesIni prof = new ProfilesIni();
		
		System.setProperty(FirefoxDriver.SystemProperty.BROWSER_LOGFILE, "/dev/null");	
		FirefoxProfile profile = prof.getProfile("default");
		FirefoxOptions options = new FirefoxOptions();
		
		options.setProfile(profile);
//>>> Firefox driver with profile	
//		driver = new FirefoxDriver(options);
//>>> Firefox driver without profile	
// 		driver = new FirefoxDriver();
		
		
//>>> Chrome driver					
//		
//		System.setProperty("webdriver.chrome.driver","C:/Users/Cesar G/Selenium Project/lib/chromedriver.exe");
//      ChromeOptions opt =new ChromeOptions();
//      driver = new ChromeDriver(opt );		
//		driver = new ChromeDriver();

//>>> IE driver											
//		System.setProperty("webdriver.ie.driver","C:/Users/Cesar G/Selenium Project/lib/IEDriverServer.exe");
//		driver = new InternetExplorerDriver();

		driver = new HtmlUnitDriver();
		
	}
	
	@Test
	public void testCase()
	{

		driver.manage().window().maximize();
		driver.navigate().to("http://google.com");
		Assert.assertEquals(driver.getTitle(),"Google");
		
		try {
			Thread.sleep(3000);
		} catch (Exception e) {	}
		
}
	
	@Test
	public void testCase2()
	{

		driver.get("http://www.youtube.com");
		Assert.assertEquals(driver.getTitle(),"YouTube");
		
		try {
			Thread.sleep(3000);
		} catch (Exception e) {	}
		

		
		

	}
	
	
	
	@AfterClass
	public static void stopWebDriver() {
//		driver.close();
		driver.quit();
		
		if ( driver != null )
		{
			driver = null ;
		}
			
		
	}




}
