package testcase;

import helper.LinkHelper;
import helper.StartWebDriver;

import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.FluentWait;
import org.testng.annotations.Test;

import com.google.common.base.Function;

public class TestFluentWait extends StartWebDriver {
	@SuppressWarnings("deprecation")
	
	@Test
	public void testWait() {
		
		LinkHelper.clickLink("File");
		
		FluentWait<WebDriver> wait = new FluentWait<WebDriver>(driver);
		wait.withTimeout(30,TimeUnit.SECONDS);
		wait.pollingEvery(5,TimeUnit.MILLISECONDS);
		
		wait.ignoring( NoSuchElementException.class );

		
		Function<WebDriver,WebElement> fun = new Function<WebDriver,WebElement>() {
			@Override
			public WebElement apply (WebDriver arg0 ) {
				System.out.println("Not Found");
				return arg0.findElement(By.id("log_in"));
			}
			
		};
		
		wait.until( fun ).click();
		
		System.out.println("Element Found");
	}
	

}
