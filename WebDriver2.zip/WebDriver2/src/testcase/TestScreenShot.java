package testcase;

import org.openqa.selenium.JavascriptExecutor;
import org.testng.annotations.Test;



import helper.GenericHelper;
import helper.StartWebDriver;

public class TestScreenShot extends StartWebDriver{

	@Test
	public void ScreenShot() {

		driver.get("http://www.noticias24.com/");	
		JavascriptExecutor exe = 	(JavascriptExecutor) driver;
		exe.executeScript("window.scrollTo(0,0)");
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
		
		}	
				
		
		Boolean check = (Boolean) exe.executeScript("return document.documentElement.scrollHeight > document.documentElement.clientHeight");
		
		Long ScrollH = (Long) exe.executeScript("return document.documentElement.scrollHeight");
		Long ClientH = (Long) exe.executeScript("return document.documentElement.clientHeight");
		
		int index = 1;
		
		if ( check.booleanValue()) {
			while (ScrollH.intValue() > 0 ) {
				GenericHelper.takeScreenShot("shot-" + index);
				exe.executeScript("window.scrollTo(0,"+ClientH*index+")");
				ScrollH = ScrollH - ClientH;

				try {
					Thread.sleep(2000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}	
				index++;				
				System.out.println(" try - " + index);
			}	
			
		}
		else
		{
			GenericHelper.takeScreenShot("shot-1");	
		}
		
		
	
		System.out.println("print shot taken");
	}
}
