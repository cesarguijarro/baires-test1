package testcase;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.ie.InternetExplorerOptions;
import org.openqa.selenium.remote.DesiredCapabilities;

public class FirstTestCase {

	public static void main(String[] args) {
	//	FirefoxDriver driver = new FirefoxDriver();

        //driver = new InternetExplorerDriver();

		
		//System.setProperty("webdriver.ie.driver","C:\\Users\\Cesar G\\Selenium Project\\lib\\IEDriverServer.exe");
		//InternetExplorerDriver driver = new InternetExplorerDriver();
		
		System.setProperty("webdriver.chrome.driver","C:\\Users\\Cesar G\\Selenium Project\\lib\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
	}

}
