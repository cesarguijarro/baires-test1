package testcase;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;

import helper.ButtonHelper;
import helper.CheckBoxHelper;
import helper.LinkHelper;
import helper.StartWebDriver;
import helper.TextBoxHelper;

public class TestRadioButton extends StartWebDriver {
	
	@Test
	public void testRadioButton() {
		LinkHelper.clickLink("File a Bug");
		TextBoxHelper.typeInTextBox("Bugzilla_login", "cesarguijarro@gmail.com");
		TextBoxHelper.typeInTextBox("Bugzilla_password", "rfp0265");
		CheckBoxHelper.clickCheckBox("Bugzilla_restrictlogin");
		ButtonHelper.clickButton("log_in");
		Assert.assertTrue(driver.getTitle().contains("Enter"));
		//LinkHelper.clickLink("Administration"); <<< this generates an error !!
		ButtonHelper.clickButton("div#header ul.links li:nth-of-type(9)>a");
		//driver.findElement(By.cssSelector("div#header ul.links li:nth-of-type(9)>a")).click();
		LinkHelper.clickLink("Parameters");
		Assert.assertTrue(driver.getTitle().contains("Configuration"));
		CheckBoxHelper.clickCheckBox("ssl_redirect-on");
		System.out.println("Selected : " + CheckBoxHelper.isChecked("ssl_redirect-off"));
		
		
	}

}