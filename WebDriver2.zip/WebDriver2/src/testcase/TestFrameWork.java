package testcase;

import java.io.File;
import java.io.FileInputStream;
import java.util.List;
import java.util.Properties;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import org.openqa.selenium.By;
import org.openqa.selenium.By.ByLinkText;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.google.common.collect.Table.Cell;

import helper.ButtonHelper;
import helper.CheckBoxHelper;
import helper.ComboBoxHelper;
import helper.GenericHelper;
import helper.LinkHelper;
import helper.ReadConfigProperty;
import helper.ReadExcelFile;
import helper.StartWebDriver;
import helper.TextBoxHelper;

import java.io.File;
import java.io.FileInputStream;



public class TestFrameWork extends StartWebDriver {
	
	public static String email; 
	
	public void TestURL_ok() {
	/*** Step 1: To verify that the page load gracefully  ***/
		Assert.assertEquals(driver.getCurrentUrl(), "https://www.consumeraffairs.com/");
		System.out.println(" >>>> TestURL_>>> OK " );
	}
	
	public void TestClickWriteReview_ok() {
	/*** Step 2 : Click on the "Write a Review" link at the top of the page  *///
		
		if(driver.findElements(By.cssSelector("[data-track=\"header_review_btn\"]")).size() == 1)
		{
			// css : [data-track="header_review_btn"]
			// xpath  //header[@id='ca-hdr']//form[@action='https://www.consumeraffairs.com/review/']/button[@name='campaign_link_submit']
			//a[@id='before-header-search-block site-header__menu-link']
			
			System.out.println("Link Write Review found ");
			driver.findElement(By.cssSelector("[data-track=\"header_review_btn\"]")).click();
		}
		else
		{
			// Link Write a Review not found
			System.out.println("Link Write a Review not found");
			assert( 1 == 0 );
		}
	/*** Step 3 : You should be taken to a page titled "Write a Review", with a Heading Let's get started  ***/ 

		Assert.assertEquals(driver.getTitle(), "Write a Review");

		Assert.assertEquals(driver.findElement(By.cssSelector(".step-header")).getText(), "Let's get started");
		

		System.out.println(" >>>> TestClickWriteReview_ok >>> OK " );		
   		
	}
	
	public void TestClickCreateAccount_ok() {
	/*** Step3 : ...  Click on the "Create account" button.  and click on it, then load to a Create Account page ***/
		
		if ( driver.findElements(By.linkText("Create account")).size() == 1)
		{
			driver.findElement(By.linkText("Create account")).click();
			System.out.println("Step 3 : >>>  OK ");
			System.out.println(" >>>> TestClickCreateAccount_ok  >>> OK " );					
		}
		else
		{
			assert( 1 == 0 );	
		}
		
	/***  Step4 : You should be taken to a page titled "Create your account", with a heading of "Create your account".  ***/
    //    Title of the page Create your account 
		
		Assert.assertEquals(driver.getTitle(), "Create your account");
		System.out.println("Step 4 : Page Create your account : ok  ");		
	//    Head of the page Create your account	
	//    css : h1
	//    xpath : /html//body[@id='page']/div[@class='offcanvas-wrap']/div[@class='offcanvas-inner-wrap']//h1[.='Create your account']
	//	          /html/body/div[1]/div/div/div/div/div/header/h1

		Assert.assertEquals(driver.findElement(By.xpath("//h1")).getText(), "Create your account");
		
		System.out.println("Step 4 : with heading Create your account: Ok ");
	}
	
	
	public void TestFillOuttheForm_ok() {
    try {
	    // Step 4 : Fill out the form using a random test email and password and click "Continue".
        // 	TODO  Put the filename in the properties 
    	// Properties prop = new Properties();
		// Use the class ReadExcelFile !!!
		
		// load file
	    XSSFWorkbook book = new XSSFWorkbook(ReadExcelFile.class.getClassLoader().getResourceAsStream("resource/input.xlsx"));
		XSSFSheet sheet = book.getSheet("data");
	    
		email = sheet.getRow(0).getCell(0).getStringCellValue();
		
		System.err.println("email : " + sheet.getRow(0).getCell(0).getStringCellValue());
		System.err.println("Password : " + sheet.getRow(0).getCell(1).getStringCellValue());
		
		TextBoxHelper.typeInTextBox("email", sheet.getRow(0).getCell(0).getStringCellValue());
		TextBoxHelper.typeInTextBox("email2", sheet.getRow(0).getCell(0).getStringCellValue());
		TextBoxHelper.typeInTextBox("password1",sheet.getRow(0).getCell(1).getStringCellValue() );	
		TextBoxHelper.typeInTextBox("password2", sheet.getRow(0).getCell(1).getStringCellValue());
		
		if ( driver.findElements(By.cssSelector(".form-actions button")).size() == 1)  
		{
			driver.findElement(By.cssSelector(".form-actions button")).click();
			System.out.println("Step 4 : >>>  OK ");
			System.out.println(" >>>> TestFillOuttheForm_ok  >>> OK " );					
		}
		else
		{
			assert( 1 == 0 );	
		}
	}
    catch (Exception e) {
		   System.out.println(e.getMessage());
		 
	}
	}
	
	public void TestContactInformationPage_ok() {
	/*** Step 5: You should be taken to a Contact Information page with a title and heading of "Create an account".   ***/
		Assert.assertEquals(driver.getTitle(), "Create an account");
		Assert.assertEquals(driver.findElement(By.xpath("//h1")).getText(), "Create an account");
	/*** Step 5: Fill in the contact information form with dummy details.       ***/
		TextBoxHelper.typeInTextBox("id_first_name", "Peter");
		TextBoxHelper.typeInTextBox("id_last_name", "Gabriel");
		TextBoxHelper.typeInTextBox("id_phone", "1234567890");
		TextBoxHelper.typeInTextBox("id_address", "Addres Line 1");
		TextBoxHelper.typeInTextBox("id_address2", "Addres Line 2");		
		TextBoxHelper.typeInTextBox("id_city", "Ciudad - 1");		

		ComboBoxHelper.selectByVisibleText("id_state", "Other/International");
		TextBoxHelper.typeInTextBox("id_zip", "11111");	
		ComboBoxHelper.selectByVisibleText("id_country", "Andorra");
		
		if (CheckBoxHelper.isChecked("id_newsletter")) {
			CheckBoxHelper.clickCheckBox("id_newsletter");	
		}
		
		// Click on Create account

		if ( driver.findElements(By.cssSelector(".form-actions button")).size() == 1)  
		{
			driver.findElement(By.cssSelector(".form-actions button")).click();
			System.out.println("Step 5 : >>>  OK ");
			System.out.println(" >>>> TestContactInformationPage_ok  >>> OK " );					
		}
		else
		{
			assert( 1 == 0 );	
		}
		
	}
	
	public void TestGettingtoKnowYou_ok() {
	/*** Step 6: You should be taken to a page with title and heading of "Getting to know you".  ***/

		Assert.assertEquals(driver.getTitle(), "Getting to know you");
		Assert.assertEquals(driver.findElement(By.xpath("//h1")).getText(), "Getting to know you");
		
			
		if ( driver.findElements(By.cssSelector("[href=\"\\?skip\\=1\\&next\\=\\%2Freview\\%2Fwrite\\%2Frn\\%2F\"]")).size() == 1)  
		{
			driver.findElement(By.cssSelector("[href=\"\\?skip\\=1\\&next\\=\\%2Freview\\%2Fwrite\\%2Frn\\%2F\"]")).click();
			System.out.println("Step 6 : >>>  OK ");
			System.out.println(" >>>> TestGettingtoKnowYou_ok  >>> OK " );					
		}
		else
		{
			assert( 1 == 0 );	
		}

	}
	
	public void TestEndCreate_ok() {
	/*** Step 6: You should be taken to a page with title and heading of "Getting to know you".  ***/
		String ContentText; 

		Assert.assertEquals(driver.getTitle(), "Thanks for creating an account");
		Assert.assertEquals(driver.findElement(By.xpath("//h1")).getText(), "Thank you");
		
			
		if ( driver.findElements(By.cssSelector("strong")).size() == 1)  
		{
			//driver.findElement(By.cssSelector("strong")).click();
			System.out.println("Step 6 : >>>  OK ");
			System.out.println(" >>>> TestGettingtoKnowYou_ok  >>> OK " );					
		}
		else
		{
			assert( 1 == 0 );	
		}
		
		ContentText = driver.findElement(By.xpath("//body[@id='page']//div[@class='page-content-wrap']/div[@class='page-content']/div/div[@class='row']/section//div[@class='offset1 span10 thank_you']/section/p[4]")).getText();
		
		Assert.assertEquals(ContentText.contains(email), true) ;
		
		System.out.println(" >>>> TestGettingtoKnowYou_ok Confirmation message  >>> OK " );		
	}



	
    @Test
	public void testCase() {
		TestURL_ok();
		TestClickWriteReview_ok();
		TestClickCreateAccount_ok();
        TestFillOuttheForm_ok();
        TestContactInformationPage_ok();
        TestGettingtoKnowYou_ok();
        TestEndCreate_ok();
        
	}
	
}
