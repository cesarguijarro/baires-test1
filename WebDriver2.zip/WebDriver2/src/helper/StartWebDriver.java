package helper;

import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

public class StartWebDriver {
	
	public static WebDriver driver = null;
	
	@BeforeSuite
	public void setUp(){
		try {
			
			ReadConfigProperty file = new ReadConfigProperty();
			if("firefox".equalsIgnoreCase(file.getBrowser())){
				driver = new FirefoxDriver();
			}else if("chrome".equalsIgnoreCase(file.getBrowser())){
				System.setProperty("webdriver.chrome.driver","C:\\Users\\Cesar G\\Selenium Project\\workspace\\WebDriver2\\src\\resource\\chromedriver.exe");
//				System.setProperty("webdriver.chrome.driver", StartWebDriver.class.getClassLoader().getResource("resource/chromedriver.exe").getPath());
				driver = new ChromeDriver();
			}else if("exlorer".equalsIgnoreCase(file.getBrowser())){
				System.setProperty("webdriver.ie.driver", StartWebDriver.class.getClassLoader().getResource("resource/IEDriverServer.exe").getPath());
				driver = new InternetExplorerDriver();
			}else{
				driver = new HtmlUnitDriver();
			}
			driver.manage().timeouts().pageLoadTimeout(file.getPageWait(), TimeUnit.SECONDS);
			driver.manage().timeouts().implicitlyWait(file.getElementWait(), TimeUnit.SECONDS);
			driver.get(file.getUrl());	
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	protected static WebElement getElement(String locator) {
		boolean flag = false;
		if(locator.contains("/"))
			flag = true;
		if(driver.findElements(By.id(locator)).size() == 1){
			return driver.findElement(By.id(locator));
		}else if(driver.findElements(By.name(locator)).size() == 1 ){
			return driver.findElement(By.name(locator));
		}else if(!flag && driver.findElements(By.cssSelector(locator)).size() == 1){
			return driver.findElement(By.cssSelector(locator));
		}else if(driver.findElements(By.xpath(locator)).size() == 1){
			return driver.findElement(By.xpath(locator));
		}else
			throw new NoSuchElementException("No Such Element : " + locator);
		
	}
	
	@AfterSuite(alwaysRun=true)
	public void tearDown() {
		try {
//			driver.close();
			driver.quit();
			if(driver != null)
				driver = null;
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	

}
